---
id: 2
title: About
date: 2017-06-21T07:07:08+00:00
author: AnonV
layout: page
guid: http://whitehack.ga/?page_id=2
---
This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.